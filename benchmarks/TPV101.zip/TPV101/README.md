# TPV101

Spontaneous rupture on a vertical strike-slip fault in a homogeneous fullspace. Rate-state friction, using an ageing law.


- [The SCEC/USGS Spontaneous Rupture Code Verification Project](http://scecdata.usc.edu/cvws/)
- [TPV101 Documentation](http://scecdata.usc.edu/cvws/tpv101_102docs.html)